import random

print("Welcome to Guess the Number")
print("The rules are simple. I will think of a number, and you will try to guess it..")

number = random.randint(1,10)

isGuestRight = False

while isGuestRight != True:
    guess = input("Guess a number between 1 and 10: ")
    if int(guess) == number:
        print("You Guessed {}. That is correct!".format(guess))
        isGuestRight = True
    else:
        print("You Guessed {}. sorry, that isn't it. the correct is {} Try again.".format(guess,number))



