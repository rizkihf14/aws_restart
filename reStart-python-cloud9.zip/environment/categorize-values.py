myMixedTypeList = [45, 290578,1.08,True,"My Dog Is One The Bed.", "45"]
print(myMixedTypeList)

for item in myMixedTypeList :
    print("{} is of the data type {}".format(item,type(item)))
    
    